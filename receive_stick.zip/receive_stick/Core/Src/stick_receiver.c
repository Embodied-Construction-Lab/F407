#include "stick_receiver.h"

#include <ctype.h>
#include <errno.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>

void StickReceiver_Init(StickReceiver *receiver)
{
  if (receiver != NULL)
  {
    memset(receiver, 0, sizeof(*receiver));
  }
}

void StickReceiver_FeedFromIsr(StickReceiver *receiver,
                               const uint8_t *data,
                               uint16_t size)
{
  uint16_t index;

  if ((receiver == NULL) || (data == NULL))
  {
    return;
  }

  for (index = 0U; index < size; ++index)
  {
    const uint8_t byte = data[index];

    if (byte == (uint8_t)'\r')
    {
      continue;
    }

    if (byte == (uint8_t)'\n')
    {
      if (receiver->dropping_frame != 0U)
      {
        receiver->dropping_frame = 0U;
        receiver->current_length = 0U;
        continue;
      }

      if (receiver->current_length != 0U)
      {
        const uint8_t next_head =
            (uint8_t)((receiver->head + 1U) % STICK_QUEUE_SLOTS);

        if (next_head == receiver->tail)
        {
          receiver->dropped_frames++;
        }
        else
        {
          memcpy(receiver->frames[receiver->head], receiver->current,
                 receiver->current_length);
          receiver->frames[receiver->head][receiver->current_length] = '\0';
          receiver->lengths[receiver->head] = receiver->current_length;
          receiver->head = next_head;
        }
      }
      receiver->current_length = 0U;
      continue;
    }

    if (receiver->dropping_frame != 0U)
    {
      continue;
    }

    if (receiver->current_length >= (STICK_FRAME_MAX_LEN - 1U))
    {
      receiver->dropping_frame = 1U;
      receiver->current_length = 0U;
      receiver->dropped_frames++;
      continue;
    }

    receiver->current[receiver->current_length++] = (char)byte;
  }
}

bool StickReceiver_Pop(StickReceiver *receiver,
                       char *frame,
                       size_t frame_capacity)
{
  uint16_t length;

  if ((receiver == NULL) || (frame == NULL) ||
      (receiver->tail == receiver->head))
  {
    return false;
  }

  length = receiver->lengths[receiver->tail];
  if (frame_capacity <= (size_t)length)
  {
    return false;
  }

  memcpy(frame, receiver->frames[receiver->tail], length + 1U);
  receiver->tail = (uint8_t)((receiver->tail + 1U) % STICK_QUEUE_SLOTS);
  return true;
}

static bool parse_number(const char *frame, const char *key, float *value)
{
  const char *position = frame;
  const size_t key_length = strlen(key);

  while ((position = strstr(position, key)) != NULL)
  {
    char *end;
    float parsed;

    position += key_length;
    while (isspace((unsigned char)*position) != 0)
    {
      ++position;
    }
    if (*position != ':')
    {
      continue;
    }
    ++position;
    while (isspace((unsigned char)*position) != 0)
    {
      ++position;
    }

    errno = 0;
    parsed = strtof(position, &end);
    if ((end == position) || (errno == ERANGE) || !isfinite(parsed))
    {
      return false;
    }

    *value = parsed;
    return true;
  }

  return false;
}

static bool parse_direct_data(const char *frame, StickData *stick)
{
  return parse_number(frame, "\"X1\"", &stick->x1) &&
         parse_number(frame, "\"Y1\"", &stick->y1) &&
         parse_number(frame, "\"Z1\"", &stick->z1) &&
         parse_number(frame, "\"X2\"", &stick->x2) &&
         parse_number(frame, "\"Y2\"", &stick->y2) &&
         parse_number(frame, "\"Z2\"", &stick->z2);
}

bool StickReceiver_ParseJson(const char *frame, StickData *stick)
{
  StickData parsed;

  if ((frame == NULL) || (stick == NULL))
  {
    return false;
  }

  if (!parse_direct_data(frame, &parsed))
  {
    return false;
  }

  *stick = parsed;
  return true;
}
