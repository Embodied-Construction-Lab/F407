#include "truck_control.h"

#include "servo_control.h"

#include <stddef.h>

#define PEDAL_DEAD_ZONE_PERCENT 2.0f

static float TruckControl_Absolute(float value)
{
  return (value < 0.0f) ? -value : value;
}

static float TruckControl_Clamp(float value, float minimum, float maximum)
{
  if (value < minimum)
  {
    return minimum;
  }
  if (value > maximum)
  {
    return maximum;
  }
  return value;
}

static float TruckControl_ClampSteeringAxis(float value)
{
  value = TruckControl_Clamp(value, -1.0f, 1.0f);

  return (TruckControl_Absolute(value) <= TRUCK_STEERING_DEAD_ZONE) ?
      0.0f : value;
}

static float TruckControl_PedalToPercent(float raw_axis)
{
  const float minimum =
      (TRUCK_PEDAL_RELEASED_RAW < TRUCK_PEDAL_PRESSED_RAW) ?
      TRUCK_PEDAL_RELEASED_RAW : TRUCK_PEDAL_PRESSED_RAW;
  const float maximum =
      (TRUCK_PEDAL_RELEASED_RAW > TRUCK_PEDAL_PRESSED_RAW) ?
      TRUCK_PEDAL_RELEASED_RAW : TRUCK_PEDAL_PRESSED_RAW;
  const float denominator =
      TRUCK_PEDAL_RELEASED_RAW - TRUCK_PEDAL_PRESSED_RAW;
  float percent;

  if ((denominator > -0.0001f) && (denominator < 0.0001f))
  {
    return 0.0f;
  }

  raw_axis = TruckControl_Clamp(raw_axis, minimum, maximum);
  percent = (TRUCK_PEDAL_RELEASED_RAW - raw_axis) * 100.0f / denominator;
  percent = TruckControl_Clamp(percent, 0.0f, 100.0f);

  if (percent <= PEDAL_DEAD_ZONE_PERCENT)
  {
    percent = 0.0f;
  }
  return percent;
}

void TruckControl_SetNeutral(TruckOutputs *outputs)
{
  if (outputs == NULL)
  {
    return;
  }

  outputs->pwm_count[TRUCK_CHANNEL_STEERING] =
      ServoControl_AngleToPulse(90.0f);
  outputs->pwm_count[TRUCK_CHANNEL_DRIVE] =
      ServoControl_SpeedToPulse(0.0f);
  outputs->pwm_count[TRUCK_CHANNEL_UNUSED] = 0U;
  outputs->pwm_count[TRUCK_CHANNEL_LIFT] =
      ServoControl_SpeedToPulse(0.0f);
  outputs->steering_deg = 90;
  outputs->throttle_percent = 0;
  outputs->brake_percent = 0;
  outputs->drive_percent = 0;
  outputs->lift_percent = 0;
}

void TruckControl_SetDrivePercent(TruckOutputs *outputs,
                                  int16_t drive_percent)
{
  if (outputs == NULL)
  {
    return;
  }
  if (drive_percent > 100)
  {
    drive_percent = 100;
  }
  else if (drive_percent < -100)
  {
    drive_percent = -100;
  }

  outputs->drive_percent = drive_percent;
  outputs->pwm_count[TRUCK_CHANNEL_DRIVE] =
      ServoControl_SpeedToPulse((float)drive_percent);
}

void TruckControl_SetLiftPercent(TruckOutputs *outputs,
                                 int16_t lift_percent)
{
  if (outputs == NULL)
  {
    return;
  }
  if (lift_percent > TRUCK_LIFT_UP_MAX_PERCENT)
  {
    lift_percent = TRUCK_LIFT_UP_MAX_PERCENT;
  }
  else if (lift_percent < -TRUCK_LIFT_DOWN_MAX_PERCENT)
  {
    lift_percent = -TRUCK_LIFT_DOWN_MAX_PERCENT;
  }

  outputs->lift_percent = lift_percent;
  outputs->pwm_count[TRUCK_CHANNEL_LIFT] =
      ServoControl_SpeedToPulse((float)lift_percent);
}

void TruckControl_MapRawCommand(const TruckCommand *command,
                                TruckOutputs *outputs)
{
  float steering_angle;
  float throttle;
  float brake;
  float drive;
  float lift_speed = 0.0f;

  if ((command == NULL) || (outputs == NULL))
  {
    return;
  }

  steering_angle =
      (TruckControl_ClampSteeringAxis(
           command->steering * TRUCK_STEERING_DIRECTION) + 1.0f) * 90.0f;
  throttle = TruckControl_PedalToPercent(command->throttle);
  brake = TruckControl_PedalToPercent(command->brake);
  drive = ((brake > 0.0f) ? -brake : throttle) *
      TRUCK_DRIVE_MAX_PERCENT / 100.0f;

  if ((command->up != 0U) && (command->down == 0U))
  {
    lift_speed = (float)TRUCK_LIFT_UP_MAX_PERCENT;
  }
  else if ((command->down != 0U) && (command->up == 0U))
  {
    lift_speed = -(float)TRUCK_LIFT_DOWN_MAX_PERCENT;
  }

  outputs->pwm_count[TRUCK_CHANNEL_STEERING] =
      ServoControl_AngleToPulse(steering_angle);
  outputs->pwm_count[TRUCK_CHANNEL_UNUSED] = 0U;
  outputs->steering_deg = (int16_t)(steering_angle + 0.5f);
  outputs->throttle_percent = (int16_t)(throttle + 0.5f);
  outputs->brake_percent = (int16_t)(brake + 0.5f);
  TruckControl_SetDrivePercent(
      outputs, (int16_t)((drive >= 0.0f) ?
                         (drive + 0.5f) : (drive - 0.5f)));
  TruckControl_SetLiftPercent(
      outputs, (int16_t)((lift_speed >= 0.0f) ?
                         (lift_speed + 0.5f) :
                         (lift_speed - 0.5f)));
}

void TruckEsc_Init(TruckEscController *controller)
{
  if (controller != NULL)
  {
    controller->state = TRUCK_ESC_NEUTRAL;
    controller->state_started_ms = 0U;
    controller->output_percent = 0;
  }
}

void TruckEsc_Reset(TruckEscController *controller)
{
  TruckEsc_Init(controller);
}

int16_t TruckEsc_Update(TruckEscController *controller,
                        int16_t requested_percent,
                        uint32_t now_ms)
{
  if (controller == NULL)
  {
    return 0;
  }
  if (requested_percent > 100)
  {
    requested_percent = 100;
  }
  else if (requested_percent < -100)
  {
    requested_percent = -100;
  }

  switch (controller->state)
  {
    case TRUCK_ESC_NEUTRAL:
      if (requested_percent > 0)
      {
        controller->state = TRUCK_ESC_FORWARD;
        controller->output_percent = requested_percent;
      }
      else if (requested_percent < 0)
      {
        controller->state = TRUCK_ESC_BRAKE_FOR_REVERSE;
        controller->state_started_ms = now_ms;
        controller->output_percent = requested_percent;
      }
      else
      {
        controller->output_percent = 0;
      }
      break;

    case TRUCK_ESC_FORWARD:
      if (requested_percent < 0)
      {
        controller->state = TRUCK_ESC_BRAKE_FOR_REVERSE;
        controller->state_started_ms = now_ms;
        controller->output_percent = requested_percent;
      }
      else if (requested_percent == 0)
      {
        controller->state = TRUCK_ESC_NEUTRAL;
        controller->output_percent = 0;
      }
      else
      {
        controller->output_percent = requested_percent;
      }
      break;

    case TRUCK_ESC_BRAKE_FOR_REVERSE:
      if (requested_percent >= 0)
      {
        controller->state = (requested_percent > 0) ?
            TRUCK_ESC_FORWARD : TRUCK_ESC_NEUTRAL;
        controller->output_percent = requested_percent;
      }
      else if ((uint32_t)(now_ms - controller->state_started_ms) >=
               TRUCK_ESC_BRAKE_TIME_MS)
      {
        controller->state = TRUCK_ESC_REVERSE_NEUTRAL;
        controller->state_started_ms = now_ms;
        controller->output_percent = 0;
      }
      else
      {
        controller->output_percent = requested_percent;
      }
      break;

    case TRUCK_ESC_REVERSE_NEUTRAL:
      if (requested_percent >= 0)
      {
        controller->state = (requested_percent > 0) ?
            TRUCK_ESC_FORWARD : TRUCK_ESC_NEUTRAL;
        controller->output_percent = requested_percent;
      }
      else if ((uint32_t)(now_ms - controller->state_started_ms) >=
               TRUCK_ESC_REVERSE_NEUTRAL_TIME_MS)
      {
        controller->state = TRUCK_ESC_REVERSE;
        controller->output_percent = requested_percent;
      }
      else
      {
        controller->output_percent = 0;
      }
      break;

    case TRUCK_ESC_REVERSE:
      if (requested_percent < 0)
      {
        controller->output_percent = requested_percent;
      }
      else
      {
        controller->state = (requested_percent > 0) ?
            TRUCK_ESC_FORWARD : TRUCK_ESC_NEUTRAL;
        controller->output_percent = requested_percent;
      }
      break;

    default:
      TruckEsc_Reset(controller);
      break;
  }

  return controller->output_percent;
}

bool TruckControl_IsActiveChannel(uint8_t channel)
{
  return (channel < TRUCK_OUTPUT_CHANNELS) &&
         (channel != TRUCK_CHANNEL_UNUSED);
}

bool TruckControl_IsTimedOut(uint32_t now_ms, uint32_t last_valid_ms)
{
  return (uint32_t)(now_ms - last_valid_ms) > TRUCK_CONTROL_TIMEOUT_MS;
}
